using UnityEngine;
using Pathfinding.Serialization.JsonFx;
using System.Collections;

public class Sketch : MonoBehaviour {

    public GameObject myPrefab;
    string _WebsiteURL = "http://copp576.azurewebsites.net/tables/trelloactivity?zumo-api-version=2.0.0";

    void Start () {
        string jsonResponse = Request.GET(_WebsiteURL);

        if (string.IsNullOrEmpty(jsonResponse))
        {
            return;
        }

		Trello[] rows = JsonReader.Deserialize<Trello[]>(jsonResponse);

		int totalCubes = rows.Length;
        int totalDistance = 10;
        int i = 0;
		foreach (Trello row in rows)
        {
            float perc = i / (float)totalCubes;
            i++;
            float x = perc * totalDistance;
            float y = 10.0f;
            float z = 0.0f;
            GameObject newCube = (GameObject)Instantiate(myPrefab, new Vector3( x, y, z), Quaternion.identity);
            newCube.GetComponent<CubeCode>().SetSize((1.0f - perc) *2);
			newCube.GetComponent<CubeCode>().RotateSpeed = perc;
			newCube.GetComponentInChildren<TextMesh>().text = row.CardName;


            if (row.ListName == "Ass2Done") {
                newCube.GetComponent<Renderer>().material.color = Color.green; // OR Color.Red;
            }
            else {
                newCube.GetComponent<Renderer>().material.color = Color.red; // OR Color;
            }
 




        }        
	}
	
	void Update () {
	
	}
}
